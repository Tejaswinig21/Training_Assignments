package com.myapp;

import org.apache.commons.lang3.StringUtils;

public class Test {

    public static void main(String[] args) {
        String s="abcd";
        System.out.println(StringUtils.capitalize(s));
    }
}
